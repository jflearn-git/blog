//任意值设置的运动框架

function getstyle(obj, attr) { //本函数作用只有一个 :获取值  代替offset家族
	if(obj.currentStyle) {
		return obj.currentStyle[attr];
	} else {
		return getComputedStyle(obj, false)[attr];
	}
}

//parseInt(getstyle(obj,name));获取到当前值   等同于之前的offset家族

function move(obj, json, refn) { //attr 属性名
	clearInterval(obj.timer);

	obj.timer = setInterval(function() {
		var isstop = true; //关
		for(var attr in json) {

			//var nowval=parseInt(getstyle(obj,attr)); //获取到当前值   等同于之前的offset家族
			var nowval = 0;
			if(attr == 'opacity') { // 0.2  20
				nowval = Math.round(parseFloat(getstyle(obj, attr)) * 100); //  parseFloat  浮点型  保留小数
				//nowval=parseInt(getstyle(obj,attr)*100);//  parseFloat  浮点型  保留小数
			} else {
				nowval = Math.round(parseInt(getstyle(obj, attr)));
			}
			//1   缓冲运动公式
			var speed = (json[attr] - nowval) / 10;
			//2   缓冲运动取整
			speed = speed > 0 ? Math.ceil(speed) : Math.floor(speed);
			//3 判断当前值是否等于目标值

			if(nowval !== json[attr]) { //如果当前值不等于json中的若干属性,那么不关定时器
				isstop = false; //只要有一个属性没达到目标值,那就不关掉
			}
			//							else{
			//								isstop=true;  //当前值等于目标值，就关掉定时器   只要有一个不达到那就关掉，所以不存在else
			//							}

			if(attr == 'opacity') {
				obj.style.filter = 'alpha(opacity:' + (nowval + speed) + ')'; //ie
				obj.style.opacity = (nowval + speed) / 100;
			} else {
				obj.style[attr] = nowval + speed + 'px';
			}

		}

		if(isstop) { // 如果条件成立,就是true, 结合前面的判断,true就是关掉定时器
			clearInterval(obj.timer); //已经达到

			if(refn) {//为做链式运动在定时器结束后，开始调用
				refn();
			}
		}

	}, 30);
}