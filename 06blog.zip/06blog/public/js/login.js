//	登录验证开始
	//点击表单
		//	<form method="post" action="#" onsubmit="adaptValue();">
		//注册执行
		$('*').find('[name="username"]').val(''),
		$('.now').on('submit', adaptValue)
		//邮箱验证 onblur="v_account();" onkeyup="v_account();
		$('.now').find('#e-mail').find('input').on({
			blur: v_account,
			keyup: v_account
		})
	
		//验证密码

		$('.now').find('#line_password').find('input').on({
			blur: v_password,
			keyup: v_password
		})

		//注册按钮
		$('.now').find('#agree-btn').find('.readagreement-wrap').on('click', onReadAgreementClick)
		$('.now').find('#agree-btn').find('input').on('change', v_submitbutton)
		$('.now').find('#agree-btn').find('a').on('click', showAgreement)

		//同意用户条款按钮
		$('.now').find('#agreement').find('input').on('click', agree)

		//当bool存在的时候，可以注册
		function enableSubmit(bool) {
			//submit注册按钮，根据是否满足条件来确定是否可以点击已经改变样式
			if(bool) $('.now').find("#submit").removeAttr("disabled").css({background:'green',cursor:'pointer'})
			else $('.now').find("#submit").attr("disabled", "disabled").css({background:'#ddd',cursor:'no-drop'})
		}
		//每次输入完后，验证是否可以点击
		function v_submitbutton() {
			//验证是否符合条件
			//验证条款是否同意了，如果不同意不可以注册
			if($('.now').find("#agree").attr("checked") != "checked") {
				enableSubmit(false);
				//条款的外部边框
				return;
			} else {
		
			}
			//flags全为true时提交按钮解除禁用  
			for(f in flags)
				if(!flags[f]) {
					$("#submit")
					enableSubmit(false);
					return;
				}
			enableSubmit(true);
		}
		//用户使用协议agreement
		function showAgreement() {
			$('.now').find("#readagreement").removeAttr("onclick");
			$('.now').find("#agreement").show();
		}

		function agree() {
			$('.now').find("#agreement").hide();
			$('.now').find("#readagreement").attr("onclick", "showAgreement();");
			//	触发 #agree 元素的 click 事件：
			if($('.now').find("#agree").attr("checked") != "checked") $('.now').find("#agree").trigger("click");
		}

		function onReadAgreementClick() {
			return;
			if($('.now').find("#agree").attr("checked")) {
				$('.now').find("#agree").removeAttr("checked");
			} else {
				$('.now').find("#agree").attr("checked", "checked");
			}
			v_submitbutton();
		}
		var flags = [false,true, false, true];
		//邮箱验证，网上找到的正则
		var RegEmail = /^([a-zA-Z0-9]+[_|\_|\.]?)*[a-zA-Z0-9]+@([a-zA-Z0-9]+[_|\_|\.]?)*[a-zA-Z0-9]+\.[a-zA-Z]{2,3}$/;

		function lineState(name, state, msg) {
			if(state == "none") {
				$('.now').find("#line_" + name + " .input div").attr("class", "none");
				return;
			}
			if(state == "corect") {
				$('.now').find("#line_" + name + " .input div").attr("class", "corect");
				return;
			}
			//相应的输入框，对应的span标签输出对应的错误信息
			$('.now').find("#line_" + name + " .input span").text(msg);
			$('.now').find("#line_" + name + " .input div").attr("class", "error");
		}
		//验证邮箱
		function v_account() {
			var account =$('.now').find("#account").val();
			if(!RegEmail.test(account)) {
				lineState("account", "error", "邮箱格式不正确");
				flags[0] = false;
				enableSubmit(false);
			} else {
				lineState("account", "corect", "");
				flags[0] = true;
			}
			v_submitbutton();
		}

		//验证密码
		function v_password() {
			var password = $('.now').find("#password").val();
			if(password.length < 6) {
				lineState("password", "error", "必须多于或等于6个字符");
				flags[2] = false;
			} else {
				if(password.length > 16) {
					lineState("password", "error", "必须少于或等于16个字符");
					flags[2] = false;
				} else {
					lineState("password", "corect", "");
					flags[2] = true;
				}
			}
		
			v_submitbutton();
		}
		//验证重复密码
		function v_repeat() {
			if(!flags[2]) {
				lineState("repeat", "none", "");
				return;
			}
			if($('.now').find("#password").val() != $("#repeat").val()) {
				lineState("repeat", "error", "密码不一致");
				flags[3] = true;
			} else {
				lineState("repeat", "corect", "");
				flags[3] = true;
			}
			v_submitbutton();
		}

		function adaptValue() {
			return true;
		}
		

//	登录验证开始
//		清空输入框
        $('*').find('input').find('[name="username"]').val(),
						
		//点击表单
		//	<form method="post" action="#" onsubmit="adaptValue2();">
		//注册执行
		$('.now2').on('submit', adaptValue2)
		//邮箱验证 onblur="v_account2();" onkeyup="v_account2();
		$('.now2').find('#e-mail').find('input').on({
			blur: v_account2,
			keyup: v_account2
		})
	
		//验证密码
		
		$('.now2').find('#line_password').find('input').on({
			blur: v_password2,
			keyup: v_password2
		})
		$('.now2').find('#line_repeat').find('input').on({
			blur: v_repeat2,
			keyup: v_repeat2
		})
		//注册按钮
		$('.now2').find('#agree2-btn').find('.readagree2ment-wrap').on('click', onReadagree2mentClick2)
		$('.now2').find('#agree2-btn').find('input').on('change', v_submitbutton2)
		$('.now2').find('#agree2-btn').find('a').on('click', showagree2ment2)

		//同意用户条款按钮
		$('.now2').find('#agree2ment').find('input').on('click', agree2)

		//当bool存在的时候，可以注册
		function enableSubmit2(bool) {
			//submit注册按钮
			if(bool) $('.now2').find("#submit").removeAttr("disabled").css({background:'green',cursor:'pointer'});
			else $('.now2').find("#submit").attr("disabled", "disabled").css({background:'#ddd',cursor:'no-drop'});
		}
		//每次输入完后，验证是否可以点击
		function v_submitbutton2() {
			//验证是否符合条件
			//验证条款是否同意了，如果不同意不可以注册
			if($('.now2').find("#agree2").attr("checked") != "checked") {
				enableSubmit2(false);
				//条款的外部边框
				return;
			} else {
		
			}
			//flags2全为true时提交按钮解除禁用  
			for(f in flags2)
				if(!flags2[f]) {
					enableSubmit2(false);
					return;
				}
			enableSubmit2(true);
		}
		//用户使用协议agree2ment
		function showagree2ment2() {
			$('.now2').find("#readagree2ment").removeAttr("onclick");
			$('.now2').find("#agree2ment").show();
		}

		function agree2() {
			$('.now2').find("#agree2ment").hide();
			$('.now2').find("#readagree2ment").attr("onclick", "showagree2ment2();");
			//	触发 #agree2 元素的 click 事件：
			if($('.now2').find("#agree2").attr("checked") != "checked") $('.now2').find("#agree2").trigger("click");
		}

		function onReadagree2mentClick2() {
			return;
			if($('.now2').find("#agree2").attr("checked")) {
				$('.now2').find("#agree2").removeAttr("checked");
			} else {
				$('.now2').find("#agree2").attr("checked", "checked");
			}
			v_submitbutton2();
		}
		var flags2 = [false,true, false, false];
		//邮箱验证，网上找到的正则
		var RegEmail2 = /^([a-zA-Z0-9]+[_|\_|\.]?)*[a-zA-Z0-9]+@([a-zA-Z0-9]+[_|\_|\.]?)*[a-zA-Z0-9]+\.[a-zA-Z]{2,3}$/;

		function lineState2(name, state, msg) {
			if(state == "none") {
				$('.now2').find("#line_" + name + " .input div").attr("class", "none");
				return;
			}
			if(state == "corect") {
				$('.now2').find("#line_" + name + " .input div").attr("class", "corect");
				return;
			}
			//相应的输入框，对应的span标签输出对应的错误信息
			$("#line_" + name + " .input span").text(msg);
			$("#line_" + name + " .input div").attr("class", "error");
		}
		//验证邮箱
		function v_account2() {
			var account = $('.now2').find("#account").val();
			if(!RegEmail2.test(account)) {
				lineState2("account", "error", "邮箱格式不正确");
				flags2[0] = false;
				enableSubmit2(false);
			} else {
				lineState2("account", "corect", "");
				flags2[0] = true;
			}
			v_submitbutton2();
		}

		//验证密码
		function v_password2() {
			var password =$('.now2').find("#password").val();
			if(password.length < 6) {
				lineState2("password", "error", "必须多于或等于6个字符");
				flags2[2] = false;
			} else {
				if(password.length > 16) {
					lineState2("password", "error", "必须少于或等于16个字符");
					flags2[2] = false;
				} else {
					lineState2("password", "corect", "");
					flags2[2] = true;
				}
			}
			v_repeat2();
			v_submitbutton2();
		}
		//验证重复密码
		function v_repeat2() {
			if(!flags2[2]) {
				lineState2("repeat", "none", "");
				return;
			}
			if($('.now2').find("#password").val() != $('.now2').find("#repeat").val()) {
				lineState2("repeat", "error", "密码不一致");
				flags2[3] = false;
			} else {
				lineState2("repeat", "corect", "");
				flags2[3] = true;
			}
			v_submitbutton2();
		}

		function adaptValue2() {
			return true;
		}