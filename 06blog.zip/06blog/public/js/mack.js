$('.cd-popup-trigger0').on('click', function(event) {
					event.preventDefault();
					$('.cd-popup').addClass('is-visible');
					$("body").css("overflow", "hidden")
					//$(".dialog-addquxiao").hide()
				});
				//关闭窗口
				$('.cd-popup').on('click', function(event) {
					if($(event.target).is('.cd-popup-close') || $(event.target).is('.cd-popup')) {
						event.preventDefault();
						$(this).removeClass('is-visible');
						$("body").css("overflow", "auto")
					}
				});
				//ESC关闭
				$(document).keyup(function(event) {
					if(event.which == '27') {
						$('.cd-popup').removeClass('is-visible');
						$("body").css("overflow", "auto")
						
					}
				});
