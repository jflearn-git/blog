function tabSwitch(_this, num) {
	var tag = document.getElementById("nav9");
	var number = tag.getElementsByTagName("a"); //获取导航栏元素个数(getElementsByTagName是返回元素素组)  
	var divNum = document.getElementsByClassName("eachDiv"); //获取导航元素对应的div个数  
	for(var i = 0; i < number.length; i++) { //number是一个数组，这里应该用number.length显示它的长度5  
		number[i].className = " "; //清除所有导航栏元素的特殊样式  
		divNum[i].style.display = "none"; //其他所有div都隐藏  
	}
	_this.className = "l_nav1_no1"; //给当前导航栏元素添加样式  
	var content = document.getElementById("l_no2_" + num); //当前导航栏元素对应的div  
	content.style.display = "block"; //显示当前导航栏元素对应的div部分  
}