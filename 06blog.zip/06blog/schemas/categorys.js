//定义一个数据表结构
var mongoose = require('mongoose')
module.exports = new mongoose.Schema({
	//分类名
	name:String
	
})


