var mongoose = require('mongoose');
var contentSchema = require('../schemas/contents');

//使用usersSchema创建模型类然后对数据进行操作
//输出一个User模型类然后对数据库进行操作
module.exports = mongoose.model('Content',contentSchema)


