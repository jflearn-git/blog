/*
 * 應用程序接口
 */
var express = require('express');
var app = express();
var swig = require('swig');
var mongoose = require('mongoose');
//解析post提交的数据
var bodyParser = require('body-parser');
//使用cookies保存用户的登录状态
var cookies = require('cookies');
//引入模型获取信息是否是管理员，models
var User = require('./models/User');


app.engine('html',swig.renderFile);
//解析并返回给客户端
app.set('views','./views');
app.set('view engine','html')

app.use('/public',express.static(__dirname+'/public'));

app.use(bodyParser.urlencoded({extended:true}))

//给res增加一个属性
app.use(function(req,res,next){
	//需要向cookies传入req，res对象
	res.cookies = new cookies(req,res);
	req.userInfo = {};
	//如果cookies中有登录的信息，将它存到req.userInfo中，使用swig模板的render函数的第二个参数传递值，通过值使用{% if userInfo._id %}{% else %}{% else if %}//渲染登录注册或登录后的模板
	if(res.cookies.get('userInfo')){
		try{//数据在返回给浏览器时浏览器会获取，通过render，可以给前端页面添加数据，main.js
			req.userInfo = JSON.parse(res.cookies.get('userInfo'))
			
			User.findById(req.userInfo._id).then(function(userInfo){
				req.userInfo.isAdmin = Boolean(userInfo.isAdmin);
				next();
				//查到的信息以布尔值的方式存储
  			})
			
			//在入口文件中进行判断是否是管理员用户
			
		}catch(e){
			next()
		}
	}else{
		next()
	}

})

//根据路由执行文件,然后在对应的文件中写路由分配
app.use('/admin',require('./routers/admin'))
app.use('/api',require('./routers/api'))
app.use('/',require('./routers/main'))
app.use('/project',require('./routers/project'))

//不在缓存中读取，调试过程中开启，上线删掉
swig.setDefaults({cache:false})

//l链接数据库
mongoose.connect('mongodb://localhost:27017/blog',function(err){
	if(err){
		console.log('数据库链接失败')
		console.log(err)
	}else{
		console.log('数据库链接成功')
		 
		app.listen(8080,()=>{
			console.log('监听了8080端口')
		})

	}
})



















