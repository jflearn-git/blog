//使用router功能
 var express = require('express');
 var router = express.Router();
 //用户数据
var User = require('../models/User')
//分类数据
var Category = require('../models/Category')
//文章内容
var Content = require('../models/Content')


router.use(function(req,res,next){
	if(!req.userInfo.isAdmin){
		res.send('抱歉，只有管理员才可以访问此页面')
		return;
	}
	next()
})
 router.get('/',function(req,res){
 	res.render('./admin/index',{
 		userInfo:req.userInfo
 	})
 })
 
router.get('/user',function(req,res){
	
	var page = Number(req.query.page || 1) ;
	var limit = 6;
	
	var pages = 0;

	User.count().then(function(count){

		pages = Math.ceil(count / limit);
////		//限定最小值
		page = Math.min(page,pages);
////		//限定最大值
//		page = Matn.max(page,1);
		page = Math.max(page,1)
		
		var skip = (page - 1)*limit;
		//User查询的数据
		User.find().limit(limit).skip(skip).then(function(users){
//			console.log(users)
			res.render('./admin/user_index',{
				userInfo:req.userInfo,
	 			users:users,
	 			
	 			url:'user',
	 			page:page,
	 			count:count,
	 			pages:pages,
	 			limit:limit
	 		})
		})
	
	})

})
//分类管理
router.get('/category',function(req,res,next){
	
	var page = Number(req.query.page || 1) ;
	var limit = 6;
	
	var pages = 0;

	Category.count().then(function(count){

		pages = Math.ceil(count / limit);
////		//限定最小值
		page = Math.min(page,pages);
////		//限定最大值
//		page = Matn.max(page,1);
		page = Math.max(page,1)
		
		var skip = (page - 1)*limit;
		//User查询的数据
		Category.find().sort({_id:-1}).limit(limit).skip(skip).then(function(categorys){
		
			res.render('./admin/category_index',{
				userInfo:req.userInfo,
	 			categorys:categorys,
	 			
	 			url:'category',
	 			page:page,
	 			count:count,
	 			pages:pages,
	 			limit:limit
	 		})
		})
	
	})
})
//分类添加
router.get('/category/add',function(req,res,next){
	
		res.render('./admin/user_add',{
			userInfo:req.userInfo
		})
})
//添加分类
router.post('/category/add',function(req,res){
	
	var name = req.body.name || '';
	if(name==''){
		res.render('./admin/err',{
			userInfo:req.userInfo,
			message:'名称不能为空'
		})
		return;
	}
	
	//查询数据库中是否存在
	 Category.findOne({
	 	name:name
	 }).then(function(rs){
	 	if(rs){
	 		res.render('./admin/err',{
	 			userInfo:req.userInfo,
	 			message:'分类已经存在'
	 		})
	 		return Promise.reject();
	 	}else{
	 		//数据库中不存在该分类，可以保存
	 		return new Category({
	 			name:name
	 		}).save();
	 	}
	 
	 }).then(function(newCategory){
	 	res.render('admin/success',{
	 		userInfo:req.userInfo,
	 		message:'分类保存成功',
	 		url:'admin/category'
	 	})
	 })
	
})


//点击修改分类信息
router.get('/category/edit',function(req,res){
	
	var id = req.query.id || '';
	Category.findOne({_id:id}).then(function(category){
		if(!category){
			res.render('./admin/err',{
				userInfo:req.userInfo,
				message:'分类信息不存在'
			})
		}else{
			res.render('./admin/category_edit',{
				userInfo:req.userInfo,
				category:category
			})
		}
	
	})
})


router.post('/category/edit',function(req,res){
	var id = req.query.id.toString();
	var name = req.body.name || '';
	
	Category.findOne({_id:id}).then(function(category){
		if(!category){
			res.render('./admin/err',{
				userInfo:req.userInfo,
				message:'分类信息不存在'
			})
				return Promise.reject();
			
		}else{
			//要修改的分类名称是否已经在数据库中存在
			if(name == category.name){
				res.render('admin/success',{
					userInfo:req.userInfo,
					message:'修改成功',
					url:'/admin/category'
					
				});
				return Promise.reject();
			}else{
				//要修改名称是否已经在数据库中存在
			return	Category.findOne({
					_id:{$ne:id},//id不是id，name是name
					name:name
				})
		
			}
		}
	
	}).then(function(sameCategory){
//		console.log('是否存在数据'+sameCategory)
		if(sameCategory){
			res.render('admin/err',{
				userInfo:req.userInfo,
				message:'数据库中已经存在此数据'
			})
			return Promise.reject();
		}else{//将数据存入
			 return Category.update({
				_id:id
			},{
				name:name
			})
		}
	}).then(function(){
		res.render('admin/success',{
			userInfo:req.userInfo,
			message:'修改成功',
			url:'/admin/category'
					
		});
	})
	

})

//分类删除
router.get('/category/delete',function(req,res){
	var id = req.query.id || '';

//	console.log(id)
	Category.remove({
		_id:id
	}).then(function(){
		res.render('admin/success',{
			userInfo:req.userInfo,
			message:'删除成功',
			urlto:'/admin/category'
		})
		
	})
})

//内容管理
router.get('/content',function(req,res){
	
	var page = Number(req.query.page || 1) ;
	var limit = 6;
	var pages = 0;

	Content.count().then(function(count){

		pages = Math.ceil(count / limit);
////		//限定最小值
		page = Math.min(page,pages);
////		//限定最大值
//		page = Matn.max(page,1);
		page = Math.max(page,1)
		
		var skip = (page - 1)*limit;
		//User查询的数据
		Content.find().sort({_id:-1}).limit(limit).skip(skip).populate(['category','user']).then(function(contents){
				
			res.render('./admin/content_index',{
				userInfo:req.userInfo,
	 			contents:contents,
	 		
	 	
	 			url:'content',
	 			page:page,
	 			count:count,
	 			pages:pages,
	 			limit:limit
	 		})
		})
	
	})

})
//内容添加主页
router.get('/content/add',function(req,res){
	
	
	Category.find().sort({_id:-1}).then(function(categorys){
		res.render('admin/content_add',{
		userInfo:req.userInfo,
		categorys:categorys

		})
	})
	
	
})

//内容添加处理
router.post('/content/add',function(req,res){
	if(req.body.title == ''){
		res.render('admin/err',{
			userInfo:req.userInfo,
			message:'标题不能为空'
		})
		return;
	}
	if(req.body.category == ''){
		res.render('admin/err',{
			userInfo:req.userInfo,
			message:'分类不能为空'
		})
		return;
	}

	//将数据保存到数据库   new Content({}).save().then(function(){})
	new Content({
		category:req.body.category,
		title:req.body.title,
		content:req.body.content,
		user:req.userInfo,
		description:req.body.description
	}).save().then(function(re){
		res.render('admin/success',{
			userInfo:req.userInfo,
			message:'内容保存成功'
		})
	})
	
	
	
})
//修改文章内容
router.get('/content/edit',function(req,res){
	//获取当前要修改的数据的ID
	var id = req.query.id || '';
	
	Category.find().then(function(categorys){
	
		Content.findOne({_id:id}).populate('category').then(function(rs){
			if(!rs){
				res.render('admin/err',{
					userInfo:userInfo,
					message:'文章不存在'
				})
				return;
			}
			
			res.render('admin/content_edit',{
				userInfo:req.userInfo,
				title:rs.title,
				content:rs.content,
				description:rs.description,
				id:rs.category._id,
				categorys:categorys
			})
		})		
	})
})
//文章内容的保存

router.post('/content/edit',function(req,res){
	var id = req.query.id || '';
	
	
		if(req.body.title == ''){
		res.render('admin/err',{
			userInfo:req.userInfo,
			message:'标题不能为空'
		})
		return;
		}
		if(req.body.category == ''){
			res.render('admin/err',{
				userInfo:req.userInfo,
				message:'分类不能为空'
			})
			return;
		}
	
		//将数据保存到数据库   new Content({}).save().then(function(){})
	 	Content.update({
	 		_id:id	
	 	}
	 	,{
			category:req.body.category,
			title:req.body.title,
			content:req.body.content,
			description:req.body.description
		}).then(function(re){
			res.render('admin/success',{
				userInfo:req.userInfo,
				message:'内容修改成功',
				url:'/admin/content/edit?id='+id
			})
		})
		
	
})

//点击删除数据
router.get('/content/delete',function(req,res){
	var id = req.query.id || '';
	
	Content.remove({
		_id:id
	}).then(function(){
		res.render('admin/success',{
			userInfo:req.userInfo,
			message:'删除成功',
			urlto:'/admin/content?id='+id
		})
	})
})



//输出router对象
module.exports = router;































