//使用router功能
 var express = require('express');
 var router = express.Router();
 


 
//一号店首页
 router.get('/yihao',function(req,res,next){
 	res.render('project/yihao/index');
 
 })
// 404页面
 router.get('/err',function(req,res,next){
 	res.render('project/yihao/404');
 
 })
 //uc页面

 router.get('/lunbotu',function(req,res,next){
 	res.render('project/lunbotu/index');
 
 })

module.exports = router;
