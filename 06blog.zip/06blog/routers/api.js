//使用router功能
 var express = require('express');
 var router = express.Router();
 
 var User = require('../models/User')
 var Content = require('../models/Content')
// 由于需要返回数据回前端
//下面定义统一的数据返回格式
  var responseData;

//
////初始化信息，错误码和返回信息
//首先会执行这个use如果没有next不会向下执行
router.use(function(req,res,next){
	responseData = {
		code:0,
		message:''
	}
	
	next()
})
// 
 

 router.post('/user/register',function(req,res,next){
 	
   	var username = req.body.username;
   	var password = req.body.password;
   	var repassword = req.body.repassword;
   	
   	
   	if(username == ''){
   		responseData.code = 1;
   		responseData.message = '用户名不能为空';
   		res.json(responseData);
   		return;
   	}
   	//密码不能为空
   	if(password == ''){
   		responseData.code = 2;
   		responseData.message = '密码不能为空';
   		res.json(responseData);
   		return;
   	}
   	if(password != repassword){
   		responseData.code = 3;
   		responseData.message = '两次密码不相同';
   		res.json(responseData);
   		return;
   	}
   	
   	User.findOne({
   		username:username
   	}).then(function(userInfo){
   	
   		if(userInfo){
   			
   			responseData.code = 4;
			responseData.message = '用户名已被注册'
			res.json(responseData);
			return;
   		}
   		const users = new User({
		username:username,
		password:password
		});
		return users.save();
   	}).then(function(newUserInfo){
//		console.log('写入数据库的数据'+newUserInfo);
		responseData.message = '注册成功';
 	 	res.json(responseData)
		
	})
   	
   
   	
 })

//处理登录请求api/user/login username
 router.post('/user/login',function(req,res,next){
 	var username = req.body.username;
 	var password = req.body.password;
 	
 	if(username == ''   || password == ''){
 		responseData.code = 1;
 		responseData.message = '密码或用户名不能为空';
 		res.json(responseData);
 	}
 	
 	//在数据库中查询
 	User.findOne({
 		username:username,
 		password:password
 	}).then(function(userInfo){
 		if(!userInfo){
 			responseData.code=2;
 			responseData.message = '用户名或密码错误';
 			res.json(responseData)
 			return;
 		}
 		//返回数据库中的内容
   		responseData.userInfo = {
			_id:userInfo._id,
			username:userInfo.username
		}
 		responseData.message = '登录成功';
 		//使用set方法储存cookies信息\
 		//字符串的形式返回
 		res.cookies.set('userInfo',JSON.stringify({
 			_id:userInfo._id,
			username:userInfo.username
 		}))
 		res.json(responseData)
 		
 	})
 	
 })
 //退出
 router.get('/user/logout',function(req,res,next){
 	res.cookies.set('userInfo',null)
 	res.json(responseData)
 })


//评论提交的Api

router.post('/comment/post',function(req,res){
	//内容的ID
	var contentId = req.body.contentid || '';
	
	var postData = {
		userInfo:req.userInfo.username,
		postTime:new Date(),
		content:req.body.content
	};
	
	//查询当前这篇内容的信息
	Content.findOne({
		_id:contentId
	}).then(function(content){

		content.comments.push(postData);
	
//		
//		content.save(function (error, doc) {
//		    if (error) {
//		        console.log(error);
//		    }
//		});
		
		return content.save()
	}).then(function(newContent){
		//save 返回更改的信息
		//responseData.data = newContent;
		responseData.message = '评论成功';
		responseData.data = newContent;
		res.json(responseData);
	})
	
})

//获取指定文章的所有评论
router.get('/comment',function(req,res){
	var contentId = req.query.contentid || '';
	Content.findOne({
		_id:contentId
	}).then(function(content){
		responseData.data = content.comments;
		res.json(responseData);
	})
})

//输出router对象
module.exports = router;
